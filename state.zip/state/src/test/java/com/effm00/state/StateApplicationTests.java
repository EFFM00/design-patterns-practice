package com.effm00.state;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StateApplicationTests {

	@Test
	void contextLoads() {
	}

}
